/* ============================================================
   CLOUD FUNCTION: verifyPaystackPayment
   ------------------------------------------------------------
   Called by the browser after a Paystack popup succeeds. This
   function is the ONLY place that is allowed to mark a user as
   paid — it re-checks the transaction directly with Paystack's
   servers using your SECRET key (stored safely here, never sent
   to the browser), so a spoofed client-side "success" can never
   grant access on its own.

   Deploy with:  firebase deploy --only functions

   Before deploying, set your Paystack secret key as a config value
   (do NOT paste it directly into this file):

     firebase functions:config:set paystack.secret="sk_test_xxx"

   Then in code below we read it via functions.config().paystack.secret
   ============================================================ */

const functions = require("firebase-functions");
const admin = require("firebase-admin");
const fetch = require("node-fetch");

admin.initializeApp();
const db = admin.firestore();

const EXPECTED_AMOUNT_PESEWAS = 4000; // 40 GHS x 100 (Paystack amounts are in the smallest currency subunit)

exports.verifyPaystackPayment = functions.https.onRequest(async (req, res) => {
  // Basic CORS handling so the browser can call this function directly.
  res.set("Access-Control-Allow-Origin", "*");
  res.set("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.set("Access-Control-Allow-Headers", "Content-Type, Authorization");
  if (req.method === "OPTIONS") { res.status(204).send(""); return; }
  if (req.method !== "POST") { res.status(405).json({ success:false, message:"Method not allowed" }); return; }

  try {
    // 1. Verify the caller is a signed-in Firebase user.
    const authHeader = req.headers.authorization || "";
    const idToken = authHeader.startsWith("Bearer ") ? authHeader.split("Bearer ")[1] : null;
    if (!idToken) {
      res.status(401).json({ success:false, message:"Missing auth token." });
      return;
    }
    const decoded = await admin.auth().verifyIdToken(idToken);
    const uid = decoded.uid;

    // 2. Get the transaction reference from the request body.
    const reference = req.body && req.body.reference;
    if (!reference) {
      res.status(400).json({ success:false, message:"Missing payment reference." });
      return;
    }

    // 3. Ask Paystack directly whether this transaction really succeeded.
    //    This is the step that makes the flow trustworthy — we never
    //    trust the browser's own claim of success.
    const secretKey = functions.config().paystack.secret;
    const verifyRes = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, {
      headers: { Authorization: `Bearer ${secretKey}` }
    });
    const verifyData = await verifyRes.json();

    if (!verifyData.status || verifyData.data.status !== "success") {
      res.status(400).json({ success:false, message:"Payment was not successful." });
      return;
    }

    // 4. Sanity-check the amount actually paid matches the course price.
    //    Prevents someone replaying a reference from a smaller, unrelated payment.
    if (verifyData.data.amount < EXPECTED_AMOUNT_PESEWAS) {
      res.status(400).json({ success:false, message:"Amount paid does not match the course price." });
      return;
    }

    // 5. Mark the user as paid in Firestore. This is the ONLY place in
    //    the whole system that sets paid:true — never do this from
    //    client-side JS.
    await db.collection("users").doc(uid).set({
      paid: true,
      purchaseDate: admin.firestore.FieldValue.serverTimestamp(),
      transactionRef: reference
    }, { merge: true });

    res.status(200).json({ success:true, message:"Payment verified. Course unlocked." });
  } catch (err) {
    console.error("verifyPaystackPayment error:", err);
    res.status(500).json({ success:false, message:"Internal error verifying payment." });
  }
});
